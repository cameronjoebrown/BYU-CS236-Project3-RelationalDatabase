//
//  Tuple.h
//  Project3
//
//  Created by Cam on 3/5/19.
//  Copyright © 2019 Cam. All rights reserved.
//

#ifndef Tuple_h
#define Tuple_h

#include <stdio.h>
#include <vector>
#include <string>
#include <sstream>

using namespace std;

class Tuple : public vector<string> {
public:
    Tuple();
    ~Tuple();
    string toString();
private:
    
};

#endif /* Tuple_h */
